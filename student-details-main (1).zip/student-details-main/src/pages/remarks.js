import React from "react";

const Remarks = () => {
  return <div>Remarks</div>;
};

export default Remarks;
